package kawa.lang;
/* loaded from: classes.dex */
public interface SyntaxForm {
    Object getDatum();

    TemplateScope getScope();
}

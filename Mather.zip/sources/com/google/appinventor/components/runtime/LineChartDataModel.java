package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.LineData;
/* loaded from: classes.dex */
public class LineChartDataModel extends LineChartBaseDataModel<LineChartView> {
    public LineChartDataModel(LineData data, LineChartView view) {
        super(data, view);
    }
}

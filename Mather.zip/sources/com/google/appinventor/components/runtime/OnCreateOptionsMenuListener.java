package com.google.appinventor.components.runtime;

import android.view.Menu;
/* loaded from: classes.dex */
public interface OnCreateOptionsMenuListener {
    void onCreateOptionsMenu(Menu menu);
}

package com.google.appinventor.components.runtime;
/* loaded from: classes.dex */
public interface OnClearListener {
    void onClear();
}

package com.google.appinventor.components.runtime.collect;
/* renamed from: com.google.appinventor.components.runtime.collect.package-info  reason: invalid class name */
/* loaded from: classes.dex */
interface packageinfo {
}

package com.google.appinventor.components.runtime;
/* loaded from: classes.dex */
public interface OnPauseListener {
    void onPause();
}

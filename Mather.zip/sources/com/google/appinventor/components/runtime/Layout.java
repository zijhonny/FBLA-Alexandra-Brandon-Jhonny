package com.google.appinventor.components.runtime;

import android.view.ViewGroup;
/* loaded from: classes.dex */
public interface Layout {
    void add(AndroidViewComponent androidViewComponent);

    ViewGroup getLayoutManager();
}

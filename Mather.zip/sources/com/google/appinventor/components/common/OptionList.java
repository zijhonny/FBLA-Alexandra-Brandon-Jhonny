package com.google.appinventor.components.common;
/* loaded from: classes.dex */
public interface OptionList<T> {
    /* renamed from: toUnderlyingValue */
    T mo115toUnderlyingValue();
}

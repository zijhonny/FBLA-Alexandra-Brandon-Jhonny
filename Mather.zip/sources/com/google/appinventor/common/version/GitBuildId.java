package com.google.appinventor.common.version;
/* loaded from: classes.dex */
public final class GitBuildId {
    public static final String ACRA_URI = "${acra.uri}";
    public static final String ANT_BUILD_DATE = "March 21 2023";
    public static final String GIT_BUILD_FINGERPRINT = "5bf244fbeaa2f12756f2b188647f9c77dd16d717";
    public static final String GIT_BUILD_VERSION = "nb192";

    private GitBuildId() {
    }

    public static String getVersion() {
        if (GIT_BUILD_VERSION != "" && !GIT_BUILD_VERSION.contains(" ")) {
            return GIT_BUILD_VERSION;
        }
        return "none";
    }

    public static String getFingerprint() {
        return GIT_BUILD_FINGERPRINT;
    }

    public static String getDate() {
        return ANT_BUILD_DATE;
    }

    public static String getAcraUri() {
        return ACRA_URI.equals(ACRA_URI) ? "" : ACRA_URI.trim();
    }
}

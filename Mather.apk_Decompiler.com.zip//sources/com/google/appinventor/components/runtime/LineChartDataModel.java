package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.LineData;

public class LineChartDataModel extends LineChartBaseDataModel<LineChartView> {
    public LineChartDataModel(LineData data, LineChartView view) {
        super(data, view);
    }
}

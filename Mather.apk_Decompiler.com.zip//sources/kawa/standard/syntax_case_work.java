package kawa.standard;

import gnu.expr.Declaration;
import gnu.expr.LetExp;

/* compiled from: syntax_case */
class syntax_case_work {
    Declaration inputExpression;
    LetExp let;
    Object[] literal_identifiers;
    int maxVars;

    syntax_case_work() {
    }
}
